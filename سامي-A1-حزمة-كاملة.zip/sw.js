/* Service Worker لتطبيق "قصة سامي — A1" — تخزين مؤقت تلقائي لأي ملف يُطلب (الصفحة، ملفات data/a1/*.js، الأيقونات)
   يعمل فقط عند استضافة الملفات عبر https أو localhost (متطلب قياسي في المتصفحات) — لا يعمل من file:// وهذا طبيعي وغير ضار. */
const CACHE_NAME = 'sami-a1-v1';

self.addEventListener('install', (e) => {
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
    ))
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== self.location.origin) return; // لا نتدخل بطلبات خارجية (مثل ترجمة الكلمات من الإنترنت)

  e.respondWith(
    caches.match(e.request).then((cached) => {
      const network = fetch(e.request).then((resp) => {
        if (resp && resp.status === 200) {
          const clone = resp.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(e.request, clone));
        }
        return resp;
      }).catch(() => cached);
      return cached || network;
    })
  );
});
